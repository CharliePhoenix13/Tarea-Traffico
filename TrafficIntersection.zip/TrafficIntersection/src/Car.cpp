#include "Car.h"
#include<gl\glut.h>
#include<iostream>
#include<cstdlib>

using namespace std;

Car::Car(int direction)
{
    if(direction == 1){
        x1 = 430;
        x2 = 450;
        x3 = 450;
        x4 = 430;

        y1 = 0;
        y2 = 0;
        y3 = 40;
        y4 = 40;
    }else{
        x1 = 0;
        x2 = 40;
        x3 = 40;
        x4 = 0;

        y1 = 290;
        y2 = 290;
        y3 = 310;
        y4 = 310;
    }
}

Car::~Car()
{
    //dtor
}

void Car::draw(int direction, int light, Car otherCars)
{
    if(direction == 1){
        glColor3f(0, 255, 255); // vertical car
        glBegin(GL_POLYGON);
        glVertex2i(x1, y1+steps);
        glVertex2i(x2, y2+steps);
        glVertex2i(x3, y3+steps);
        glVertex2i(x4, y4+steps);
        glEnd();
        if(light == 2 || steps < 200 || steps > 230){
            if(steps+50 < otherCars.steps || steps+50 > otherCars.steps){
                steps++;
            }
        }
        if(steps > 600){
            steps = 1;
        }
        if(steps == 199){
            cout << "Distance to light vertical car:  T - 60 \n";
        }
        glFlush();
    } else {
        glColor3f(255, 0, 255); // Horizontal car
        glBegin(GL_POLYGON);
        glVertex2i(x1+steps, y1);
        glVertex2i(x2+steps, y2);
        glVertex2i(x3+steps, y3);
        glVertex2i(x4+steps, y4);
        glEnd();
        if(light == 2 || steps < 300 || steps > 390){
            if(steps+50 < otherCars.steps || steps+50 > otherCars.steps){
                steps++;
            }
        }
        if(steps > 800){
            steps = 1;
        }
        if(steps == 299){
            cout << "Distance to light horizontal cars: T - 90\n";
        }
        glFlush();
    }
}
