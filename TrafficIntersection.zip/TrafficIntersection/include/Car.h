#ifndef CAR_H
#define CAR_H
#include "Car.h"


class Car
{
    public:
        Car(int direction);
        ~Car();
        void draw(int direction, int light, Car otherCar);
        int steps = 1;
        int x1 = 0;
        int x2 = 0;
        int x3 = 0;
        int x4 = 0;

        int y1 = 0;
        int y2 = 0;
        int y3 = 0;
        int y4 = 0;
    protected:

    private:
};

#endif // CAR_H
