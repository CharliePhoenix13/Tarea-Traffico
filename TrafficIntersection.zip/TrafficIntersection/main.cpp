#include<windows.h>
#include<gl\glut.h>
#include<math.h>
#include<vector>
#include<iostream>
#include<cstdlib>
#include<time.h>
#include <chrono>
#include <thread>
#include "Car.h"

using namespace std;
using namespace std::chrono;
using namespace std::this_thread;

int stepsVertical = 1;
int stepsHorizontal = 1;
int lightVertical = 1;
int lightHorizontal = 1;
int lightsTime = 1;
bool firstCloser = false, startLights = false;
vector <vector <int> > chessboardLogical;

Car carVertical1 = Car(1);
Car carHorizontal1 = Car(2);
Car carVertical2 = Car(1);
Car carHorizontal2 = Car(2);

void init(){
    // For displaying the window color
    glClearColor(1, 1, 1, 0);
    // Choosing the type of projection
    glMatrixMode(GL_PROJECTION);
    // for setting the transformation which here is 2D
    gluOrtho2D(0, 800, 0,600);
}

void drawCar(){
    glColor3f(0, 255, 255); // vertical car
    glBegin(GL_POLYGON);
    glVertex2i(430, 0+stepsVertical);
    glVertex2i(450, 0+stepsVertical);
    glVertex2i(450, 40+stepsVertical);
    glVertex2i(430, 40+stepsVertical);
    glEnd();
    if(lightVertical == 2 || stepsVertical < 200 || stepsVertical > 230){
        stepsVertical++;
    }
    if(stepsVertical > 600){
        stepsVertical = 1;
    }
    cout << "Distance Vertical Cars" << (200 - stepsVertical) << "\n";
    glFlush();
}

void drawCar2(){
    glColor3f(0, 0, 255); // Horizontal Car
    glBegin(GL_POLYGON);
    glVertex2i(0+stepsHorizontal, 290);
    glVertex2i(40+stepsHorizontal, 290);
    glVertex2i(40+stepsHorizontal, 310);
    glVertex2i(0+stepsHorizontal, 310);
    glEnd();
    if(lightHorizontal == 2 || stepsHorizontal < 300 || stepsHorizontal > 390){
        stepsHorizontal++;
    }
    if(stepsHorizontal > 800) {
        stepsHorizontal = 1;
    }
    cout << "Distance Horizontal Cars" << (300 - stepsHorizontal) << "\n";
    glFlush();
}

void drawStreet(){
    glColor3f(0, 0, 0); // street
    glBegin(GL_POLYGON);
    glVertex2i(400, 0);
    glVertex2i(480, 0);
    glVertex2i(480, 600);
    glVertex2i(400, 600);
    glEnd();

    //Vertical Light
    if(lightVertical == 1){
        glColor3f(255,255,0); // yellow
    }else if(lightVertical == 2){
        glColor3f(0,255,0); // green
    }else {
        glColor3f(255,0,0); //red
    }
    glBegin(GL_POLYGON);
    glVertex2i(400, 250);
    glVertex2i(480, 250);
    glVertex2i(480, 260);
    glVertex2i(400, 260);
    glEnd();

    glColor3f(0.5,0.5,0.5); // grass
    glBegin(GL_POLYGON);
    glVertex2i(390, 0);
    glVertex2i(400, 0);
    glVertex2i(400, 260);
    glVertex2i(390, 260);
    glEnd();

    glColor3f(0.5,0.5,0.5); // grass
    glBegin(GL_POLYGON);
    glVertex2i(480, 340);
    glVertex2i(490, 340);
    glVertex2i(490, 600);
    glVertex2i(480, 600);
    glEnd();

    glColor3f(0.5,0.5,0.5); // grass
    glBegin(GL_POLYGON);
    glVertex2i(390, 340);
    glVertex2i(400, 340);
    glVertex2i(400, 600);
    glVertex2i(390, 600);
    glEnd();

    glColor3f(0.5,0.5,0.5); // grass
    glBegin(GL_POLYGON);
    glVertex2i(480, 0);
    glVertex2i(490, 0);
    glVertex2i(490, 260);
    glVertex2i(480, 260);
    glEnd();

    glColor3f(0, 0, 0); // street
    glBegin(GL_POLYGON);
    glVertex2i(0, 260);
    glVertex2i(800, 260);
    glVertex2i(800, 340);
    glVertex2i(0, 340);
    glEnd();

    //Horizontal Light
    if(lightHorizontal == 1){
        glColor3f(255,255,0); // yellow
    }else if(lightHorizontal == 2){
        glColor3f(0,255,0); // green
    }else {
        glColor3f(255,0,0); //red
    }
    glBegin(GL_POLYGON);
    glVertex2i(390, 260);
    glVertex2i(400, 260);
    glVertex2i(400, 340);
    glVertex2i(390, 340);
    glEnd();

    glColor3f(0.5,0.5,0.5); // grass
    glBegin(GL_POLYGON);
    glVertex2i(0, 250);
    glVertex2i(400, 250);
    glVertex2i(400, 260);
    glVertex2i(0, 260);
    glEnd();

    glColor3f(0.5,0.5,0.5); // grass
    glBegin(GL_POLYGON);
    glVertex2i(480, 250);
    glVertex2i(800, 250);
    glVertex2i(800, 260);
    glVertex2i(480, 260);
    glEnd();

    glColor3f(0.5,0.5,0.5); // grass
    glBegin(GL_POLYGON);
    glVertex2i(0, 340);
    glVertex2i(400, 340);
    glVertex2i(400, 350);
    glVertex2i(0, 350);
    glEnd();

    glColor3f(0.5,0.5,0.5); // grass
    glBegin(GL_POLYGON);
    glVertex2i(480, 340);
    glVertex2i(800, 340);
    glVertex2i(800, 350);
    glVertex2i(480, 350);
    glEnd();
}

void chessboard(){
    glClear(GL_COLOR_BUFFER_BIT); // Clear display window
    drawStreet();
    glFlush();
}

void lightLogic(){
    if((carHorizontal1.steps >= 300 || carHorizontal2.steps >= 300) && (lightVertical == 1 || lightVertical == 3) && !(carHorizontal1.steps >= 490 && carHorizontal2.steps >= 490) && !((carHorizontal1.steps >= 490 && carHorizontal2.steps < 300) || (carHorizontal1.steps < 300 && carHorizontal2.steps >= 490))){
        lightHorizontal = 2;
        lightVertical = 3;
    } else if((carVertical1.steps >= 160 || carVertical2.steps >= 160) && (lightHorizontal == 1 || lightHorizontal == 3) && !(carVertical1.steps >= 350 && carVertical2.steps >= 350) && !((carVertical1.steps >= 350 && carVertical2.steps < 160) || (carVertical1.steps < 160 && carVertical2.steps >= 350))){
        lightHorizontal = 3;
        lightVertical = 2;
    } else if((carVertical1.steps >= 350 && carVertical2.steps >= 350) || (carVertical1.steps >= 350 && carVertical2.steps < 160) || (carVertical1.steps < 160 && carVertical2.steps >= 350) || (carVertical1.steps < 160 && carVertical2.steps < 160) && lightHorizontal != 2) {
        lightVertical = 1;
        lightHorizontal = 1;
    } else if((carHorizontal1.steps >= 490 && carHorizontal2.steps >= 490) || (carHorizontal1.steps >= 490 && carHorizontal2.steps < 300) || (carHorizontal1.steps < 300 && carHorizontal2.steps >= 490) || (carHorizontal1.steps < 300 && carHorizontal2.steps < 300) && lightVertical != 2) {
        lightHorizontal = 1;
        lightVertical = 1;
    }

    /*

    if(startLights && lightsTime <= 200){
        lightsTime++;
    }else{
        lightsTime = 1;
        int auxLight = lightVertical;
        lightVertical = lightHorizontal;
        lightHorizontal = auxLight;
    }
    */

}

static void idle(void)
{
    chessboard();
    lightLogic();
    carVertical1.draw(1, lightVertical, carVertical2);
    carHorizontal1.draw(2, lightHorizontal, carHorizontal2);
    if(stepsVertical > 150) {
        carVertical2.draw(1, lightVertical, carVertical1);
    }
    if(stepsHorizontal > 100) {
        carHorizontal2.draw(2, lightHorizontal, carHorizontal1);
    }
    stepsVertical++;
    stepsHorizontal++;
    //drawCar();
    //drawCar2();
    sleep_for(nanoseconds(10));
    sleep_until(system_clock::now() + milliseconds(30));
}

int main(int agrc, char ** argv){
    // Initialize GLUT
    glutInit(&agrc, argv);
    // Set display mode
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    // Set top - left display window position.
    glutInitWindowPosition(100, 100);
    // Set display window width and height
    glutInitWindowSize(800, 600);
    // Create display window with the given title
    glutCreateWindow("");
    // Execute initialization procedure
    init();
    // Send graphics to display window
    glutDisplayFunc(chessboard);
    // Display everything and wait.
    glutIdleFunc(idle);

    glutMainLoop();
}
